Autonomous Production Choke Controller - Technical Deliverables
==================================================================

1_Python_Code_PDF/
    ALL_SOURCE_CODE.pdf        - every Python file in one PDF, syntax-highlighted,
                                  with a table of contents (start here)
    individual_files/          - the same code, one PDF per file, if you need
                                  a specific module on its own (controller,
                                  simulator, model identification, tests, etc.)

2_Open_Loop_Step_Test_Analysis/
    step_identification.png    - the 15-step identification experiment (plots)
    step_validation.png        - the held-out validation experiment (plots)
    step_gain_curve.png        - steady-state gain vs choke position, showing
                                  the ~26x nonlinearity across the range
    step_test_identification.csv, step_test_validation.csv  - raw step-test data
    step_test_commentary.txt   - written observations on the step responses

3_Dynamic_Model_Identification/
    model_validation.png       - predicted vs actual on held-out data
                                  (NRMSE 0.09-0.95% across all four outputs)
    fitted_model.json          - the identified model (time constants + gain curve)
    model_gain_table.csv       - local steady-state gain at each choke position
    model_validation_metrics.json - RMSE / NRMSE per output

4_Autonomous_Controller_Scenario_Results/
    scenario_A.png             - Startup to Target (0 -> 120 bbl/hr)
    scenario_B.png             - Target Tracking (100 -> 150 bbl/hr)
    scenario_C.png             - Infeasible Target (200 bbl/hr requested,
                                  capped at 98.6% of the true safe maximum)

    Each scenario_*.png shows all required trends on shared time axes:
        - Target Oil Rate      (dashed line, panel 1)
        - Actual Oil Rate       (solid line, panel 1, same axes)
        - Wellhead Pressure     (panel 2, with safe-limit line)
        - Flowline Pressure     (panel 3, with safe-limit line)
        - Bottom Hole Pressure  (panel 4, with safe-limit line)
        - Choke Position        (panel 5, with the 5%/step ramp limit)

    scenario_A_log.csv, scenario_B_log.csv, scenario_C_log.csv - full
    time-series data behind each plot
    scenario_summary.json      - final settled values, min/max pressures,
                                  and PASS/FAIL safety audit per scenario

The controller implementation itself is src_controller.py.pdf inside
1_Python_Code_PDF/individual_files/ (also in ALL_SOURCE_CODE.pdf).

All results were produced by `python run_all.py` from the full project
repository: https://github.com/Ayush1Deshmukh/Autonomous-Production-Choke-Controller-for-a-Single-Naturally-Flowing-Oil-Well
Live dashboard: https://ayush1deshmukh.github.io/Autonomous-Production-Choke-Controller-for-a-Single-Naturally-Flowing-Oil-Well/
